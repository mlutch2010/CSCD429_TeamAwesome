import java.io.*;
import java.util.*;

public class Tester 
{
	//private static final String ActualTestData = "F:/CSCDCourses/CSCD 429/Project/Code/Program/src/program/track2/training.txt";
	private static final String testData = "F:/CSCDCourses/CSCD 429/Project/code/program/randomSample.txt";
	private static final String testUser = "F:/CSCDCourses/CSCD 429/Project/code/program/sampleUsers.txt";
	
	
	public static void main(String ... args) throws FileNotFoundException
	{
		Scanner fin = new Scanner(new File(testData));
		int count = 0;//variable to count how many times an ad was clicked throughout the record 
		
		count = countRecords(fin);//method to count how many times the records were hit. 		
		fin.close();
		
		fin = new Scanner(new File(testData));
		double infoOfD = getInfoOfD(count, fin);
		System.out.println(infoOfD);
		fin.close();
	}
	
	private static int countRecords(Scanner fin)
	{
		int count = 0;
		
		while(fin.hasNextLine())
		{
			String temp = fin.nextLine();
			String[] splitRecord = temp.split("\t");
			count += Integer.parseInt(splitRecord[0]);
		}
		return count;
	}
	
	private static double getInfoOfD(int count, Scanner fin)
	{
		int clicks = 0;//measures the total number of clicks
		int[] imprCountNo = new int[16];//measure the number of impressions where the index is the value for impressions
		//example if number of impressions is 2 then it will add one to the second index
		// if number of impressions is 5 then it will add one to the fifth index, etc. 
		int[] depthCountNo = new int[6];//see above but for depth 
		int[] posCountNo = new int[6];// see above but for position 
		
		
		int[] imprCountYes = new int[16];
		int[] depthCountYes = new int[16];
		int[] posCountYes = new int[6];
		
		
		double totalRecords = 0;
		int click = 0;//the parsed number of clicks 
		int impr = 0;//the impression that gets parsed out of the file every line 
		int depth = 0;// the depth that gets parsed out of the file every line 
		int pos = 0;//the position that gets parsed out of the file every line
		
		while(fin.hasNextLine())
		{
			String temp = fin.nextLine();
			String[] splitRecord = temp.split("\t");
			
			click = Integer.parseInt(splitRecord[0]);
			clicks += Integer.parseInt(splitRecord[0]);
			impr = Integer.parseInt(splitRecord[1]);
			depth = Integer.parseInt(splitRecord[5]);
			pos = Integer.parseInt(splitRecord[6]);
			
			if(click > 0)
			{
				imprCountYes[impr] = imprCountYes[impr] + 1;
				depthCountYes[depth] = depthCountYes[depth] + 1;
				posCountYes[pos] = posCountYes[pos] + 1;
			}
			else if(click == 0)
			{
				imprCountNo[impr] = imprCountNo[impr] + 1;
				depthCountNo[depth] = depthCountNo[depth] + 1;
				posCountNo[pos] = posCountNo[pos] + 1;
			}
			
			totalRecords++;
		}
		
		double infoOfD = calculateInfo(totalRecords, clicks);
		
		System.out.println("info(D) = "+ infoOfD);
		
		double infoFromImpr = findInfoFromAttribute(imprCountYes, imprCountNo, totalRecords);//finds the info sub impression of D
		double gainOfImpr = infoOfD - infoFromImpr;//calculates the information gain from impression
		System.out.println("Gain of impression = " +gainOfImpr);
		
		double infoFromDepth = findInfoFromAttribute(depthCountYes, depthCountNo, totalRecords);//finds the info sub depth of D 
		double gainOfDepth = infoOfD - infoFromDepth;//calculates the information gain from depth
		System.out.println("Gain of depth = " + gainOfDepth);
		
		double infoFromPos = findInfoFromAttribute(posCountYes, posCountNo, totalRecords);//finds the info sub pos of D
		double gainOfPos = infoOfD - infoFromPos;//calculates the information gain form position
		System.out.println("Gain of pos = " + gainOfPos);
		
		if(gainOfImpr > gainOfDepth && gainOfImpr > gainOfPos)
		{
			System.out.println("Split off of impressions");
			return gainOfImpr;
		}
		else if(gainOfDepth > gainOfImpr && gainOfDepth > gainOfPos)
		{
			System.out.println("Split off of gain");
			return gainOfDepth;
		}
		else if(gainOfPos > gainOfImpr && gainOfPos > gainOfDepth)
		{
			System.out.println("Split off of gain");
			return gainOfPos;
		}
		else return -1;
		
		
	}
	
	private static void printArray(int[] array) // prints the array that is passed in
	{
		System.out.print("[" + array[1] + ", ");
		for(int x = 2; x < array.length - 1; x++)
		{
			System.out.print(array[x] + ", ");
		}
		System.out.println(array[array.length - 1] + "]");
	}
	
	private static double calculateInfo(double totalRecords, int clicks) //calculates the info of D
	{		
		double yesClicks = clicks / totalRecords; //finds the amount of records that clicked on an add
		double noClicks = (totalRecords - clicks) / totalRecords; //finds the amount of records that did not click on an add 
		double yesClicksNum = -(yesClicks * Math.log10(yesClicks)) / Math.log10(2);
		double noClicksNum = -(noClicks * Math.log10(noClicks)) / Math.log10(2);
		//System.out.println("Info of D " + (yesClicksNum + noClicksNum));
		return yesClicksNum + noClicksNum;
	}
	
	
	private static double findInfoFromAttribute(int[] positiveValues, int[] negativeValues, double totalRecords)//calculates the info sub attribute of D
	{
		double totalCount = 0;
		double infoTotal = 0;
		double positiveRatio = 0;
		double negativeRatio = 0;
		
		for(int x = 0; x < positiveValues.length && x < negativeValues.length; x++)
		{
			totalCount = positiveValues[x] + negativeValues[x];
			
			if(totalCount != 0 && positiveValues[x] != 0 && negativeValues[x] != 0)
			{
				positiveRatio = positiveValues[x] / totalCount;
				negativeRatio = negativeValues[x] / totalCount;
				
				//System.out.println(x + ": " + positiveRatio + ", " + negativeRatio);
				double gain1 = -(positiveRatio * Math.log10(positiveRatio)/Math.log10(2));
				double gain2 = -(negativeRatio * Math.log10(negativeRatio)/Math.log10(2));
				//System.out.println(Total gain = " + (gain1 + gain2));
				infoTotal = (totalCount / totalRecords) * (gain1 + gain2);
			}
		}
		//System.out.println(infoTotal);
		return infoTotal;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
