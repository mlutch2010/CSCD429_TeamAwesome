
public class User 
{
	private int gender;
	private int age;
	private int userID;
	
	public User()
	{
		this.gender = 0; 
		this.age = 0;
		this.userID = 0;
	}
	
	public User(int userID, int gender, int age)
	{
		if(userID < 0 || gender < 0 || age < 0)
			throw new IllegalArgumentException("One of the incoming perameters for the user EVC is invalid");
		
		this.userID = userID;
		this.gender = gender;
		this.age = age;
	}
	
	public int getGender()
	{
		int gender = this.gender;
		return gender;
	}
	
	public int getAge()
	{
		int age = this.age;
		return age;
	}
	
	public int getUserID()
	{
		int userID = this.userID;
		return userID;
	}
	
	@Override
	public String toString()
	{
		String toReturn = String.valueOf(this.userID) + "\t" + String.valueOf(this.gender) + "\t" + String.valueOf(this.age);
		return toReturn;
	}
	
	public String actualAge()
	{
		switch(this.age)
		{
		case(1):
			return "0 - 12";
		case(2):
			return "13 - 18";
		case(3):
			return "19 - 24";
		case(4):
			return "25 - 30";
		case(5):
			return "31 - 40";
		case(6):
			return "41 +";
		default:
			return "-1";
		}
	}
	
	public String actualGender()
	{
		switch(this.gender)
		{
		case(1):
			return "Male";
		case(2):
			return "Female";
		case(0):
			return "Unknown";
		default:
			return "Null";
		}
	}
}
